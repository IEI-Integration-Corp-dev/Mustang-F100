1.auto fw update
	command
	$ sudo ./iei_fw_flash.sh <Firmware txt file>
	example:
 	 $ sudo ./iei_fw_flash.sh Mustang-F100_MSP430_U65_V1030_A_20181127.txt

2. manual fw update
  $ sudo ./iei_msp430_hid_tool -isp
  $ sudo PYTHONPATH=./python-msp430-tools  python -m msp430.bsl5.hid_1 -e -v -P ./Mustang-F100_MSP430_U65_V1030_A_20181127.txt
