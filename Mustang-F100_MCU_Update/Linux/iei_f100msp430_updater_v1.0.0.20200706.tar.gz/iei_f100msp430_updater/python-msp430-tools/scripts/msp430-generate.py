#!/usr/bin/env python

# command line stub for
# https://launchpad.net/python-msp430-tools

import msp430.memory.generate
msp430.memory.generate.main()
