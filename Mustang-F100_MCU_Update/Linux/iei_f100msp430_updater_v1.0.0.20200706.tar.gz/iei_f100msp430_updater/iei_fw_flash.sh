#!/bin/bash
#
#iei msp430 fw updater
#
cur_dir=$(cd $(dirname $0); pwd)
fwfile=$1
#fwfile=Mustang-V100-MX8-R10_MSP430_U53_V1011_M_20190719.txt
echo "${cur_dir}"


#check related module install

udev=$(dpkg -l |grep libudev-dev)

if [ -z "${udev}" ]
then
	echo "libudev not install, run apt-get to install"
	sudo apt-get install libudev-dev
fi

tk=$(dpkg -l |grep python-tk)
#echo ${tk}

if [ -z "${tk}" ]
then
	echo "python-tk not install, run apt-get to install"
	sudo apt-get install python-tk
fi
#version info

oldverinfo=$(sudo ${cur_dir}/iei_msp430_hid_tool -i|grep "version=")
echo "${oldverinfo}"

#switch to boot mode

echo "==========Switch to Boot Mode=========="
echo ""
echo ""


res=$(sudo ${cur_dir}/iei_msp430_hid_tool -isp)

echo "${res}"
mode=$(echo "${res}" |grep "mcu switch to boot mode") 

if [ -z "${mode}" ]
then
	echo "Switch to Boot Mode fail"
	exit -1
fi

sleep 2
vid=$(lsusb |grep "2047:0200")
if [ -z $"$vid" ]
then
	echo "Error Boot code VID/PID!!"
	exit -1

fi

echo "===========Start FW Flash==========="
echo ""
echo ""

if [ -f ${cur_dir}/${fwfile} ]
then
	echo "Flash "${cur_dir}/${fwfile}" to mcu"
else
	echo "Error fw file not exist "
	exit -1
fi


flashstr=$(sudo PYTHONPATH=${cur_dir}/python-msp430-tools python -m msp430.bsl5.hid_1 -e -v -P ${cur_dir}/${fwfile})

echo "${flashstr}"

echo "wait reset and read fw version"
sleep 25
#lsusb
newverinfo=$(sudo ${cur_dir}/iei_msp430_hid_tool -i|grep "version=")
echo "${newverinfo}"


#flashres=$(echo "${flashstr}" |grep "Programming: OK") 
#echo "$flashres"
#if [ -z "${flashres}" ]
#then
#	echo "FW Falsh Fail!!!"
#	exit -1
#else
#	echo "FW Flash Complete"
#fi
